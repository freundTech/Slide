package me.ccrama.redditslide.Adapters;

/**
 * Created by carlo_000 on 10/28/2015.
 */
public class SlideInAnimator {

}
