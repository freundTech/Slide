package me.ccrama.redditslide.ForceTouch.callback;

/**
 * Provides callbacks for the lifecycle events of the PeekView
 */
public interface OnPop {
    void onPop();
}
