package me.ccrama.redditslide.Views;

import android.content.Context;
import android.support.v4.widget.SwipeRefreshLayout;
import android.util.AttributeSet;

/**
 * Created by carlo_000 on 10/8/2015.
 */
public class GeneralSwipeRefreshLayout extends SwipeRefreshLayout {
    //TODO more to come

    public GeneralSwipeRefreshLayout(Context context) {

        super(context);
           }

    public GeneralSwipeRefreshLayout(Context context, AttributeSet attrs) {

        super(context, attrs);
         }


}