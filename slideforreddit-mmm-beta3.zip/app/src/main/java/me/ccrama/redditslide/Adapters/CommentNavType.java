package me.ccrama.redditslide.Adapters;

/**
 * Created by carlo_000 on 4/24/2016.
 */
public enum CommentNavType {
    PARENTS,CHILDREN,TIME,GILDED,OP,LINK,YOU;
    CommentNavType(){

    }
}
