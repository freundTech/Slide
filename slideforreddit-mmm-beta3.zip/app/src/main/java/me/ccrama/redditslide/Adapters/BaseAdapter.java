package me.ccrama.redditslide.Adapters;

/**
 * Created by carlo_000 on 10/30/2015.
 */
public interface BaseAdapter {
    void setError(Boolean b);

    void undoSetError();
}
