package me.ccrama.redditslide;

import android.content.Context;

public class StartupStrings {
    public static String[] startupStrings(Context context) {
        return context.getResources().getStringArray(R.array.startup_strings);
    }
}
