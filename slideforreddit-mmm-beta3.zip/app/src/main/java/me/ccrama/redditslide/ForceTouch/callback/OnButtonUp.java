package me.ccrama.redditslide.ForceTouch.callback;

import android.view.View;

/**
 * Provides callbacks for the lifecycle events of the PeekView
 */
public interface OnButtonUp {
    void onButtonUp();
}
