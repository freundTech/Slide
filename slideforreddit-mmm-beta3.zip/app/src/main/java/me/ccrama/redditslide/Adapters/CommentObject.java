package me.ccrama.redditslide.Adapters;

import net.dean.jraw.models.CommentNode;

/**
 * Created by carlo_000 on 10/27/2015.
 */
public class CommentObject {
     public boolean isComment(){
         return false;
     }

    public String getName(){
        return "";
    }

    public CommentNode comment;
}
