package me.ccrama.redditslide.Synccit;

import java.util.ArrayList;
import java.util.Set;

/**
 * Created by carlo_000 on 2/16/2016.
 */
public class SynccitRead {
    public static ArrayList<String> visitedIds = new ArrayList<>();
    public static ArrayList<String> newVisited = new ArrayList<>();
}
